<#
  Noera - servidor local del explorador de archivos.
  - Escucha SOLO en 127.0.0.1 (no accesible desde la red).
  - Opera SOLO dentro de la carpeta Noera (padre de _app). Cualquier ruta fuera se rechaza.
  - Solo gestiona extensiones de la lista $AllowedExt.
  - "Eliminar" mueve a Noera\.papelera (nunca borra de forma definitiva).
  Uso: iniciar-noera.bat   (o: powershell -ExecutionPolicy Bypass -File server.ps1)
#>
param([int]$Port = 7710, [switch]$NoBrowser)

$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Web
Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem

$AppDir = $PSScriptRoot
$Root = (Resolve-Path (Join-Path $AppDir '..')).Path.TrimEnd('\')
$AllowedExt = @('.md', '.txt', '.json', '.yml', '.yaml', '.xml', '.csv', '.toml', '.ini', '.cfg', '.properties', '.html', '.css', '.js')
$MaxEditBytes = 2MB
$MaxUploadBytes = 150MB
$Token = [Guid]::NewGuid().ToString('N')
$Utf8Strict = New-Object System.Text.UTF8Encoding($false, $true)
$MetaFile = Join-Path $AppDir 'metadata.json'

function Get-NoeraMeta() {
    if (Test-Path -LiteralPath $MetaFile) {
        try {
            $raw = [IO.File]::ReadAllText($MetaFile, [Text.Encoding]::UTF8)
            $m = ($raw | ConvertFrom-Json)
            if ($m -and $m.taggedFolders) { return $m }
        } catch { }
    }
    return [PSCustomObject]@{ taggedFolders = [PSCustomObject]@{} }
}

function Save-NoeraMeta($meta) {
    $raw = ConvertTo-Json -InputObject $meta -Depth 10
    [IO.File]::WriteAllText($MetaFile, $raw, [Text.Encoding]::UTF8)
}

$Static = @{
    '/'           = @('index.html', 'text/html; charset=utf-8')
    '/index.html' = @('index.html', 'text/html; charset=utf-8')
    '/app.css'    = @('app.css', 'text/css; charset=utf-8')
    '/app.js'     = @('app.js', 'application/javascript; charset=utf-8')
}

# ---------- utilidades ----------
function Fail([int]$code, [string]$msg) { throw "API|$code|$msg" }

function Send-Bytes($ctx, [int]$status, [string]$ctype, [byte[]]$bytes, [hashtable]$headers = $null) {
    $r = $ctx.Response
    try {
        $r.StatusCode = $status
        $r.ContentType = $ctype
        $r.Headers['Cache-Control'] = 'no-store'
        $r.Headers['X-Content-Type-Options'] = 'nosniff'
        $r.Headers['Content-Security-Policy'] = "default-src 'none'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; base-uri 'none'; form-action 'none'; frame-ancestors 'none'"
        if ($headers) {
            foreach ($k in $headers.Keys) { $r.Headers[$k] = [string]$headers[$k] }
        }
        $r.ContentLength64 = $bytes.Length
        $r.OutputStream.Write($bytes, 0, $bytes.Length)
    }
    finally { $r.OutputStream.Close() }
}

function Send-Json($ctx, [int]$status, $obj) {
    $json = ConvertTo-Json -InputObject $obj -Depth 30 -Compress
    Send-Bytes $ctx $status 'application/json; charset=utf-8' ([Text.Encoding]::UTF8.GetBytes($json))
}

function Read-Body($req, [long]$max) {
    if ($req.ContentLength64 -gt $max) { Fail 413 'Contenido demasiado grande.' }
    $ms = New-Object IO.MemoryStream
    $buf = New-Object byte[] 81920
    while (($n = $req.InputStream.Read($buf, 0, $buf.Length)) -gt 0) {
        $ms.Write($buf, 0, $n)
        if ($ms.Length -gt $max) { Fail 413 'Contenido demasiado grande.' }
    }
    return , $ms.ToArray()
}

function Read-JsonBody($req) {
    $bytes = Read-Body $req 1MB
    try { return [Text.Encoding]::UTF8.GetString($bytes) | ConvertFrom-Json }
    catch { Fail 400 'JSON inválido.' }
}

function Test-Name([string]$name, [bool]$isFile) {
    if ([string]::IsNullOrWhiteSpace($name)) { return 'El nombre está vacío.' }
    if ($name.Length -gt 120) { return 'El nombre es demasiado largo (máx. 120).' }
    if ($name -match '[\\/:*?"<>|\x00-\x1f]') { return 'Caracteres no permitidos: \ / : * ? " < > |' }
    if ($name -ne $name.Trim() -or $name.EndsWith('.')) { return 'No puede empezar/terminar con espacios ni terminar en punto.' }
    if ($name.StartsWith('.') -or $name.StartsWith('_')) { return 'No puede empezar con "." ni "_" (reservado).' }
    if ($name -match '^(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(\..*)?$') { return 'Nombre reservado de Windows.' }
    if ($isFile) {
        $ext = [IO.Path]::GetExtension($name).ToLowerInvariant()
        if ($AllowedExt -notcontains $ext) { return "Extensión no permitida ($ext). Permitidas: $($AllowedExt -join ' ')" }
    }
    return $null
}

function Assert-Name([string]$name, [bool]$isFile) {
    $e = Test-Name $name $isFile
    if ($e) { Fail 400 $e }
}

function Resolve-Rel([string]$rel, [bool]$allowRoot = $false) {
    if ($null -eq $rel) { $rel = '' }
    $rel = $rel.Replace('/', '\').Trim('\')
    if ($rel -eq '') {
        if ($allowRoot) { return $Root }
        Fail 400 'Ruta vacía.'
    }
    foreach ($seg in $rel.Split('\')) {
        if ($seg -eq '' -or $seg.StartsWith('.') -or $seg.StartsWith('_') -or $seg -match '[:*?"<>|\x00-\x1f]') { Fail 400 'Ruta inválida.' }
    }
    $full = [IO.Path]::GetFullPath((Join-Path $Root $rel))
    if (-not $full.StartsWith($Root + '\', [StringComparison]::OrdinalIgnoreCase)) { Fail 400 'Ruta fuera de Noera.' }
    return $full
}

function To-Rel([string]$full) { return $full.Substring($Root.Length + 1).Replace('\', '/') }

function Assert-Managed([string]$full) {
    if (Test-Path -LiteralPath $full -PathType Leaf) {
        $ext = [IO.Path]::GetExtension($full).ToLowerInvariant()
        if ($AllowedExt -notcontains $ext) { Fail 403 'Tipo de archivo no gestionado por Noera.' }
    }
    elseif (-not (Test-Path -LiteralPath $full -PathType Container)) { Fail 404 'No existe.' }
}

function Get-UniqueName([string]$dir, [string]$name) {
    $base = [IO.Path]::GetFileNameWithoutExtension($name)
    $ext = [IO.Path]::GetExtension($name)
    $n = $name; $i = 1
    while (Test-Path -LiteralPath (Join-Path $dir $n)) { $n = "$base ($i)$ext"; $i++ }
    return $n
}

function Test-Hidden($item) {
    return ($item.Name.StartsWith('.') -or $item.Name.StartsWith('_') -or ($item.Attributes -band [IO.FileAttributes]::ReparsePoint))
}

function Get-Children([string]$dir) {
    $dirs = Get-ChildItem -LiteralPath $dir -Directory -Force -ErrorAction SilentlyContinue | Where-Object { -not (Test-Hidden $_) } | Sort-Object Name
    foreach ($d in $dirs) {
        @{ type = 'dir'; name = $d.Name; path = (To-Rel $d.FullName); mtime = $d.LastWriteTimeUtc.Ticks.ToString(); children = @(Get-Children $d.FullName) }
    }
    $files = Get-ChildItem -LiteralPath $dir -File -Force -ErrorAction SilentlyContinue |
        Where-Object { -not (Test-Hidden $_) -and ($AllowedExt -contains $_.Extension.ToLowerInvariant()) } | Sort-Object Name
    foreach ($f in $files) {
        @{ type = 'file'; name = $f.Name; path = (To-Rel $f.FullName); ext = $f.Extension.ToLowerInvariant(); size = $f.Length; mtime = $f.LastWriteTimeUtc.Ticks.ToString() }
    }
}

function Write-FolderToZip($zip, [string]$dirPath, [string]$prefix) {
    $files = Get-ChildItem -LiteralPath $dirPath -File -Force -ErrorAction SilentlyContinue |
        Where-Object { -not (Test-Hidden $_) -and ($AllowedExt -contains $_.Extension.ToLowerInvariant()) } | Sort-Object Name
    foreach ($f in $files) {
        $entryName = if ($prefix) { "$prefix/$($f.Name)" } else { $f.Name }
        $entry = $zip.CreateEntry($entryName, [IO.Compression.CompressionLevel]::Optimal)
        $stream = $entry.Open()
        try {
            $bytes = [IO.File]::ReadAllBytes($f.FullName)
            $stream.Write($bytes, 0, $bytes.Length)
        }
        catch { }
        finally {
            $stream.Close()
        }
    }
    $subdirs = Get-ChildItem -LiteralPath $dirPath -Directory -Force -ErrorAction SilentlyContinue |
        Where-Object { -not (Test-Hidden $_) } | Sort-Object Name
    if ($files.Count -eq 0 -and $subdirs.Count -eq 0 -and $prefix) {
        [void]$zip.CreateEntry("$prefix/", [IO.Compression.CompressionLevel]::Optimal)
    }
    foreach ($d in $subdirs) {
        $subPrefix = if ($prefix) { "$prefix/$($d.Name)" } else { $d.Name }
        Write-FolderToZip $zip $d.FullName $subPrefix
    }
}

# ---------- manejo de peticiones ----------
function Handle($ctx) {
    $req = $ctx.Request
    $method = $req.HttpMethod
    $path = $req.Url.AbsolutePath

    if ($req.Headers['Host'] -ne "127.0.0.1:$Port") { Fail 403 'Host no permitido.' }

    if ($method -eq 'GET' -and $Static.ContainsKey($path)) {
        $file = Join-Path $AppDir $Static[$path][0]
        if (-not (Test-Path -LiteralPath $file)) { Fail 404 'Recurso de la aplicación no encontrado.' }
        $text = [IO.File]::ReadAllText($file, [Text.Encoding]::UTF8).Replace('{{TOKEN}}', $Token)
        Send-Bytes $ctx 200 $Static[$path][1] ([Text.Encoding]::UTF8.GetBytes($text))
        return
    }

    if (-not $path.StartsWith('/api/')) { Fail 404 'No encontrado.' }
    $q = [Web.HttpUtility]::ParseQueryString($req.Url.Query)
    $tokenHeader = $req.Headers['X-Noera-Token']
    if (-not $tokenHeader) { $tokenHeader = $q['token'] }
    if ($tokenHeader -cne $Token) { Fail 403 'Token inválido. Recarga la página.' }

    switch ("$method $path") {

        'GET /api/tree' {
            Send-Json $ctx 200 @{ root = 'Noera'; allowedExt = $AllowedExt; tree = @(Get-Children $Root) }
            return
        }

        'GET /api/file' {
            $full = Resolve-Rel $q['path']
            if (-not (Test-Path -LiteralPath $full -PathType Leaf)) { Fail 404 'El archivo no existe.' }
            Assert-Managed $full
            $fi = Get-Item -LiteralPath $full
            if ($fi.Length -gt $MaxEditBytes) { Fail 413 'Archivo demasiado grande para abrirlo (máx. 2 MB).' }
            $bytes = [IO.File]::ReadAllBytes($full)
            if ($bytes -contains 0) { Fail 415 'El archivo no es texto.' }
            try { $text = $Utf8Strict.GetString($bytes) }
            catch { Fail 415 'El archivo no es UTF-8 válido; no se abre para evitar corromperlo.' }
            if ($text.Length -gt 0 -and $text[0] -eq [char]0xFEFF) { $text = $text.Substring(1) }
            Send-Json $ctx 200 @{ path = (To-Rel $full); name = $fi.Name; content = $text; size = $fi.Length; mtime = $fi.LastWriteTimeUtc.Ticks.ToString() }
            return
        }

        'PUT /api/file' {
            $full = Resolve-Rel $q['path']
            if (-not (Test-Path -LiteralPath $full -PathType Leaf)) { Fail 404 'El archivo no existe.' }
            Assert-Managed $full
            $expected = $q['mtime']
            if ($expected -and ((Get-Item -LiteralPath $full).LastWriteTimeUtc.Ticks.ToString() -ne $expected)) {
                Fail 409 'El archivo cambió en disco desde que lo abriste.'
            }
            $bytes = Read-Body $req $MaxEditBytes
            try { [void]$Utf8Strict.GetString($bytes) } catch { Fail 400 'El contenido no es UTF-8 válido.' }
            $tmp = "$full.noera-tmp"
            try {
                [IO.File]::WriteAllBytes($tmp, $bytes)
                [IO.File]::Replace($tmp, $full, [NullString]::Value)
            }
            finally { if (Test-Path -LiteralPath $tmp) { Remove-Item -LiteralPath $tmp -Force -ErrorAction SilentlyContinue } }
            $fi = Get-Item -LiteralPath $full
            Send-Json $ctx 200 @{ mtime = $fi.LastWriteTimeUtc.Ticks.ToString(); size = $fi.Length }
            return
        }

        'POST /api/mkdir' {
            $b = Read-JsonBody $req
            $full = Resolve-Rel $b.path
            Assert-Name (Split-Path -Leaf $full) $false
            if (-not (Test-Path -LiteralPath (Split-Path -Parent $full) -PathType Container)) { Fail 404 'La carpeta padre no existe.' }
            if (Test-Path -LiteralPath $full) { Fail 409 'Ya existe un elemento con ese nombre.' }
            [void](New-Item -ItemType Directory -Path $full)
            Send-Json $ctx 200 @{ path = (To-Rel $full) }
            return
        }

        'POST /api/newfile' {
            $b = Read-JsonBody $req
            $full = Resolve-Rel $b.path
            Assert-Name (Split-Path -Leaf $full) $true
            if (-not (Test-Path -LiteralPath (Split-Path -Parent $full) -PathType Container)) { Fail 404 'La carpeta padre no existe.' }
            if (Test-Path -LiteralPath $full) { Fail 409 'Ya existe un elemento con ese nombre.' }
            [IO.File]::WriteAllBytes($full, [byte[]]@())
            Send-Json $ctx 200 @{ path = (To-Rel $full) }
            return
        }

        'POST /api/rename' {
            $b = Read-JsonBody $req
            $full = Resolve-Rel $b.path
            Assert-Managed $full
            $isFile = Test-Path -LiteralPath $full -PathType Leaf
            $newName = [string]$b.newName
            Assert-Name $newName $isFile
            $target = Join-Path (Split-Path -Parent $full) $newName
            if ($target -ceq $full) { Send-Json $ctx 200 @{ path = (To-Rel $full) }; return }
            $sameItem = ($target -ieq $full)
            if ((Test-Path -LiteralPath $target) -and -not $sameItem) { Fail 409 'Ya existe un elemento con ese nombre.' }
            if ($sameItem) {
                $tmp = Join-Path (Split-Path -Parent $full) ("noera-rename-" + [Guid]::NewGuid().ToString('N'))
                if ($isFile) { [IO.File]::Move($full, $tmp); [IO.File]::Move($tmp, $target) }
                else { [IO.Directory]::Move($full, $tmp); [IO.Directory]::Move($tmp, $target) }
            }
            elseif ($isFile) { [IO.File]::Move($full, $target) }
            else { [IO.Directory]::Move($full, $target) }
            Send-Json $ctx 200 @{ path = (To-Rel $target) }
            return
        }

        'POST /api/move' {
            $b = Read-JsonBody $req
            $src = Resolve-Rel $b.from
            $dest = Resolve-Rel $b.toDir $true
            Assert-Managed $src
            if (-not (Test-Path -LiteralPath $dest -PathType Container)) { Fail 404 'La carpeta destino no existe.' }
            $isFile = Test-Path -LiteralPath $src -PathType Leaf
            if (-not $isFile -and (($dest + '\').StartsWith($src + '\', [StringComparison]::OrdinalIgnoreCase))) { Fail 400 'No se puede mover una carpeta dentro de sí misma.' }
            $target = Join-Path $dest (Split-Path -Leaf $src)
            if ($target -ieq $src) { Send-Json $ctx 200 @{ path = (To-Rel $src) }; return }
            if (Test-Path -LiteralPath $target) { Fail 409 'En el destino ya existe un elemento con ese nombre.' }
            if ($isFile) { [IO.File]::Move($src, $target) } else { [IO.Directory]::Move($src, $target) }
            Send-Json $ctx 200 @{ path = (To-Rel $target) }
            return
        }

        'POST /api/delete' {
            $b = Read-JsonBody $req
            $full = Resolve-Rel $b.path
            Assert-Managed $full
            $rel = To-Rel $full
            $stamp = (Get-Date).ToString('yyyyMMdd-HHmmss-fff')
            $trash = Join-Path (Join-Path $Root '.papelera') $stamp
            $dest = Join-Path $trash ($rel.Replace('/', '\'))
            [void](New-Item -ItemType Directory -Path (Split-Path -Parent $dest) -Force)
            if (Test-Path -LiteralPath $full -PathType Leaf) { [IO.File]::Move($full, $dest) } else { [IO.Directory]::Move($full, $dest) }
            Send-Json $ctx 200 @{ trashed = ".papelera/$stamp/$rel" }
            return
        }

        'POST /api/upload' {
            $dir = Resolve-Rel $q['dir'] $true
            if (-not (Test-Path -LiteralPath $dir -PathType Container)) { Fail 404 'La carpeta destino no existe.' }
            $name = [string]$q['name']
            Assert-Name $name $true
            $bytes = Read-Body $req $MaxUploadBytes
            $final = Get-UniqueName $dir $name
            [IO.File]::WriteAllBytes((Join-Path $dir $final), $bytes)
            Send-Json $ctx 200 @{ path = (To-Rel (Join-Path $dir $final)); name = $final }
            return
        }

        'GET /api/zip' {
            $full = Resolve-Rel $q['path'] $true
            if (-not (Test-Path -LiteralPath $full -PathType Container)) { Fail 404 'La carpeta no existe.' }
            $folderName = if ($full -ieq $Root) { 'Noera' } else { Split-Path -Leaf $full }
            $zipName = "$folderName.zip"

            $ms = New-Object IO.MemoryStream
            $zip = New-Object IO.Compression.ZipArchive($ms, [IO.Compression.ZipArchiveMode]::Create, $true)
            Write-FolderToZip $zip $full ''
            $zip.Dispose()

            $zipBytes = $ms.ToArray()
            $ms.Dispose()

            Send-Bytes $ctx 200 'application/zip' $zipBytes @{ 'Content-Disposition' = "attachment; filename=`"$zipName`"" }
            return
        }

        'GET /api/noera/zip' {
            $zipName = "Noera-Software-Source.zip"
            $ms = New-Object IO.MemoryStream
            $zip = New-Object IO.Compression.ZipArchive($ms, [IO.Compression.ZipArchiveMode]::Create, $true)

            $batFile = Join-Path $Root 'iniciar-noera.bat'
            if (Test-Path -LiteralPath $batFile) {
                $entry = $zip.CreateEntry('iniciar-noera.bat', [IO.Compression.CompressionLevel]::Optimal)
                $stream = $entry.Open()
                $b = [IO.File]::ReadAllBytes($batFile)
                $stream.Write($b, 0, $b.Length)
                $stream.Close()
            }

            $appFiles = Get-ChildItem -LiteralPath $AppDir -File -Force -ErrorAction SilentlyContinue
            foreach ($f in $appFiles) {
                $entry = $zip.CreateEntry("_app/$($f.Name)", [IO.Compression.CompressionLevel]::Optimal)
                $stream = $entry.Open()
                $b = [IO.File]::ReadAllBytes($f.FullName)
                $stream.Write($b, 0, $b.Length)
                $stream.Close()
            }

            $zip.Dispose()
            $zipBytes = $ms.ToArray()
            $ms.Dispose()

            Send-Bytes $ctx 200 'application/zip' $zipBytes @{ 'Content-Disposition' = "attachment; filename=`"$zipName`"" }
            return
        }

        'GET /api/noera/files' {
            $coreFiles = @(
                @{ path = '_app/server.ps1'; full = (Join-Path $AppDir 'server.ps1'); lang = 'powershell' },
                @{ path = '_app/app.js'; full = (Join-Path $AppDir 'app.js'); lang = 'javascript' },
                @{ path = '_app/app.css'; full = (Join-Path $AppDir 'app.css'); lang = 'css' },
                @{ path = '_app/index.html'; full = (Join-Path $AppDir 'index.html'); lang = 'html' },
                @{ path = 'iniciar-noera.bat'; full = (Join-Path $Root 'iniciar-noera.bat'); lang = 'bat' }
            )
            $list = @()
            foreach ($c in $coreFiles) {
                if (Test-Path -LiteralPath $c.full) {
                    $fi = Get-Item -LiteralPath $c.full
                    $bytes = [IO.File]::ReadAllBytes($c.full)
                    $text = $Utf8Strict.GetString($bytes)
                    if ($text.Length -gt 0 -and $text[0] -eq [char]0xFEFF) { $text = $text.Substring(1) }
                    $list += @{
                        name = $fi.Name
                        path = $c.path
                        lang = $c.lang
                        size = $fi.Length
                        mtime = $fi.LastWriteTimeUtc.Ticks.ToString()
                        content = $text
                    }
                }
            }
            Send-Json $ctx 200 @{ files = $list }
            return
        }

        'GET /api/noera/changelog' {
            $clFile = Join-Path $AppDir 'changelog.json'
            if (Test-Path -LiteralPath $clFile) {
                $json = [IO.File]::ReadAllText($clFile, [Text.Encoding]::UTF8)
                Send-Bytes $ctx 200 'application/json; charset=utf-8' ([Text.Encoding]::UTF8.GetBytes($json))
            } else {
                Send-Json $ctx 200 @()
            }
            return
        }

        'POST /api/noera/update-zip' {
            $uploadedName = [string]$q['name']
            $allowedNames = @('Noera-Software-Source.zip', 'Noera.zip')
            if ($allowedNames -notcontains $uploadedName) {
                Fail 400 "Nombre de archivo inválido. El archivo debe llamarse exactamente 'Noera-Software-Source.zip' (o 'Noera.zip'). Recibido: '$uploadedName'."
            }

            $bytes = Read-Body $req $MaxUploadBytes
            if ($bytes.Length -lt 22) { Fail 400 'El archivo recibido está vacío o no es un ZIP válido.' }

            $tempZip = Join-Path $AppDir ("up_noera_" + [Guid]::NewGuid().ToString('N') + ".zip")
            [IO.File]::WriteAllBytes($tempZip, $bytes)

            try {
                $testZip = [IO.Compression.ZipFile]::OpenRead($tempZip)
                $entryCount = $testZip.Entries.Count
                $testZip.Dispose()
            }
            catch {
                if (Test-Path -LiteralPath $tempZip) { Remove-Item -LiteralPath $tempZip -Force -ErrorAction SilentlyContinue }
                Fail 400 'El archivo no es un ZIP válido o está dañado.'
            }

            $historyDir = Join-Path (Join-Path $Root '.history') '_noera'
            [void](New-Item -ItemType Directory -Path $historyDir -Force)
            $timestamp = (Get-Date).ToString('yyyyMMdd-HHmmss')
            $backupZipFile = "backup_${timestamp}_Noera-Software-Source.zip"
            $backupZipPath = Join-Path $historyDir $backupZipFile

            # Crear backup actual de Noera (_app y launcher)
            $ms = New-Object IO.MemoryStream
            $oldZip = New-Object IO.Compression.ZipArchive($ms, [IO.Compression.ZipArchiveMode]::Create, $true)

            $batFile = Join-Path $Root 'iniciar-noera.bat'
            if (Test-Path -LiteralPath $batFile) {
                $entry = $oldZip.CreateEntry('iniciar-noera.bat', [IO.Compression.CompressionLevel]::Optimal)
                $stream = $entry.Open()
                $b = [IO.File]::ReadAllBytes($batFile)
                $stream.Write($b, 0, $b.Length)
                $stream.Close()
            }

            $appFiles = Get-ChildItem -LiteralPath $AppDir -File -Force -ErrorAction SilentlyContinue
            foreach ($f in $appFiles) {
                $entry = $oldZip.CreateEntry("_app/$($f.Name)", [IO.Compression.CompressionLevel]::Optimal)
                $stream = $entry.Open()
                $b = [IO.File]::ReadAllBytes($f.FullName)
                $stream.Write($b, 0, $b.Length)
                $stream.Close()
            }

            $oldZip.Dispose()
            $backupBytes = $ms.ToArray()
            $ms.Dispose()
            [IO.File]::WriteAllBytes($backupZipPath, $backupBytes)
            $backupSize = $backupBytes.Length

            # Extraer a carpeta temporal
            $tempExtract = Join-Path $AppDir ("extract_noera_" + [Guid]::NewGuid().ToString('N'))
            [void](New-Item -ItemType Directory -Path $tempExtract -Force)

            try {
                [IO.Compression.ZipFile]::ExtractToDirectory($tempZip, $tempExtract)

                # Si el zip contiene _app/ o si contiene los archivos directamente
                $extractedAppDir = Join-Path $tempExtract '_app'
                $extractedBat = Join-Path $tempExtract 'iniciar-noera.bat'

                if (-not (Test-Path -LiteralPath $extractedAppDir -PathType Container)) {
                    # Si no viene la subcarpeta _app, verificar si viene una carpeta raíz contenedora tipo Noera/...
                    $firstLevelDirs = Get-ChildItem -LiteralPath $tempExtract -Directory -Force
                    if ($firstLevelDirs.Count -eq 1 -and (Test-Path -LiteralPath (Join-Path $firstLevelDirs[0].FullName '_app') -PathType Container)) {
                        $extractedAppDir = Join-Path $firstLevelDirs[0].FullName '_app'
                        $extractedBat = Join-Path $firstLevelDirs[0].FullName 'iniciar-noera.bat'
                    }
                    elseif (Test-Path -LiteralPath (Join-Path $tempExtract 'server.ps1')) {
                        # Los archivos vinieron sueltos en la raíz del ZIP
                        $extractedAppDir = $tempExtract
                    }
                }

                if (-not (Test-Path -LiteralPath $extractedAppDir -PathType Container)) {
                    Fail 400 'El ZIP no contiene una estructura válida de Noera (no se encontró carpeta _app ni server.ps1).'
                }

                # Copiar archivo lanzador iniciar-noera.bat si viene en el zip
                if (Test-Path -LiteralPath $extractedBat -PathType Leaf) {
                    Copy-Item -LiteralPath $extractedBat -Destination (Join-Path $Root 'iniciar-noera.bat') -Force
                }

                # Copiar archivos de _app a $AppDir (sobrescribir)
                $newAppFiles = Get-ChildItem -LiteralPath $extractedAppDir -File -Force
                foreach ($nf in $newAppFiles) {
                    # No sobrescribir metadata.json si el ZIP no lo trae explícitamente o preservarlo
                    if ($nf.Name -ieq 'metadata.json' -and (Test-Path -LiteralPath (Join-Path $AppDir 'metadata.json'))) {
                        # Conservar metadata actual si el nuevo es genérico/vacío
                        continue
                    }
                    Copy-Item -LiteralPath $nf.FullName -Destination (Join-Path $AppDir $nf.Name) -Force
                }
            }
            finally {
                if (Test-Path -LiteralPath $tempExtract) { Remove-Item -LiteralPath $tempExtract -Recurse -Force -ErrorAction SilentlyContinue }
                if (Test-Path -LiteralPath $tempZip) { Remove-Item -LiteralPath $tempZip -Force -ErrorAction SilentlyContinue }
            }

            # Registrar en metadata.json bajo taggedFolders['_noera']
            $meta = Get-NoeraMeta
            if (-not $meta.taggedFolders) {
                $meta | Add-Member -MemberType NoteProperty -Name 'taggedFolders' -Value ([PSCustomObject]@{})
            }
            if (-not $meta.taggedFolders.PSObject.Properties['_noera']) {
                $meta.taggedFolders | Add-Member -MemberType NoteProperty -Name '_noera' -Value ([PSCustomObject]@{
                    update = $true
                    taggedAt = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
                    history = @()
                })
            }
            $historyRecord = [PSCustomObject]@{
                id = $timestamp
                date = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
                zipName = $uploadedName
                backupRel = ".history/_noera/$backupZipFile"
                backupSize = $backupSize
                newSize = $bytes.Length
                entries = $entryCount
            }
            $currHist = @($meta.taggedFolders._noera.history)
            $currHist = @($historyRecord) + $currHist
            $meta.taggedFolders._noera.history = $currHist
            Save-NoeraMeta $meta

            Send-Json $ctx 200 @{
                ok = $true
                target = '_noera'
                zipName = $uploadedName
                history = $historyRecord
                meta = $meta
            }
            return
        }

        'GET /api/folder/meta' {
            $meta = Get-NoeraMeta
            Send-Json $ctx 200 $meta
            return
        }

        'POST /api/folder/tag' {
            $b = Read-JsonBody $req
            $relPath = [string]$b.path
            $full = Resolve-Rel $relPath $false
            if (-not (Test-Path -LiteralPath $full -PathType Container)) { Fail 404 'La carpeta no existe.' }
            $meta = Get-NoeraMeta
            if (-not $meta.taggedFolders) {
                $meta | Add-Member -MemberType NoteProperty -Name 'taggedFolders' -Value ([PSCustomObject]@{})
            }
            $enabled = [bool]$b.enabled
            if ($enabled) {
                if ($meta.taggedFolders.PSObject.Properties[$relPath]) {
                    $meta.taggedFolders.$relPath.update = $true
                } else {
                    $meta.taggedFolders | Add-Member -MemberType NoteProperty -Name $relPath -Value ([PSCustomObject]@{
                        update = $true
                        taggedAt = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
                        history = @()
                    })
                }
            } else {
                if ($meta.taggedFolders.PSObject.Properties[$relPath]) {
                    $meta.taggedFolders.$relPath.update = $false
                }
            }
            Save-NoeraMeta $meta
            Send-Json $ctx 200 @{ path = $relPath; update = $enabled; meta = $meta }
            return
        }

        'POST /api/folder/update-zip' {
            $relPath = [string]$q['path']
            $full = Resolve-Rel $relPath $false
            if (-not (Test-Path -LiteralPath $full -PathType Container)) { Fail 404 'La carpeta no existe.' }
            $folderName = Split-Path -Leaf $full
            $expectedZip = "$folderName.zip"
            $uploadedName = [string]$q['name']

            if ($uploadedName -ine $expectedZip) {
                Fail 400 "Nombre de archivo inválido. El archivo debe llamarse exactamente '$expectedZip'. Recibido: '$uploadedName'."
            }

            $bytes = Read-Body $req $MaxUploadBytes
            if ($bytes.Length -lt 22) { Fail 400 'El archivo recibido está vacío o no es un ZIP válido.' }

            $tempZip = Join-Path $AppDir ("up_temp_" + [Guid]::NewGuid().ToString('N') + ".zip")
            [IO.File]::WriteAllBytes($tempZip, $bytes)

            try {
                $testZip = [IO.Compression.ZipFile]::OpenRead($tempZip)
                $entryCount = $testZip.Entries.Count
                $testZip.Dispose()
            }
            catch {
                if (Test-Path -LiteralPath $tempZip) { Remove-Item -LiteralPath $tempZip -Force -ErrorAction SilentlyContinue }
                Fail 400 'El archivo no es un ZIP válido o está dañado.'
            }

            $historyDir = Join-Path (Join-Path $Root '.history') ($relPath.Replace('/', '\'))
            [void](New-Item -ItemType Directory -Path $historyDir -Force)
            $timestamp = (Get-Date).ToString('yyyyMMdd-HHmmss')
            $backupZipFile = "backup_${timestamp}_${expectedZip}"
            $backupZipPath = Join-Path $historyDir $backupZipFile

            $ms = New-Object IO.MemoryStream
            $oldZip = New-Object IO.Compression.ZipArchive($ms, [IO.Compression.ZipArchiveMode]::Create, $true)
            Write-FolderToZip $oldZip $full ''
            $oldZip.Dispose()
            $backupBytes = $ms.ToArray()
            $ms.Dispose()
            [IO.File]::WriteAllBytes($backupZipPath, $backupBytes)
            $backupSize = $backupBytes.Length

            $tempExtract = Join-Path $AppDir ("extract_" + [Guid]::NewGuid().ToString('N'))
            [void](New-Item -ItemType Directory -Path $tempExtract -Force)

            try {
                [IO.Compression.ZipFile]::ExtractToDirectory($tempZip, $tempExtract)

                $extractedItems = Get-ChildItem -LiteralPath $tempExtract -Force
                $sourceDir = $tempExtract
                if ($extractedItems.Count -eq 1 -and $extractedItems[0].PSIsContainer -and ($extractedItems[0].Name -ieq $folderName)) {
                    $sourceDir = $extractedItems[0].FullName
                }

                Get-ChildItem -LiteralPath $full -Force | Where-Object { -not (Test-Hidden $_) } | Remove-Item -Recurse -Force
                Get-ChildItem -LiteralPath $sourceDir -Force | ForEach-Object {
                    Move-Item -LiteralPath $_.FullName -Destination $full -Force
                }
            }
            finally {
                if (Test-Path -LiteralPath $tempExtract) { Remove-Item -LiteralPath $tempExtract -Recurse -Force -ErrorAction SilentlyContinue }
                if (Test-Path -LiteralPath $tempZip) { Remove-Item -LiteralPath $tempZip -Force -ErrorAction SilentlyContinue }
            }

            $meta = Get-NoeraMeta
            if (-not $meta.taggedFolders) {
                $meta | Add-Member -MemberType NoteProperty -Name 'taggedFolders' -Value ([PSCustomObject]@{})
            }
            if (-not $meta.taggedFolders.PSObject.Properties[$relPath]) {
                $meta.taggedFolders | Add-Member -MemberType NoteProperty -Name $relPath -Value ([PSCustomObject]@{
                    update = $true
                    taggedAt = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
                    history = @()
                })
            }
            $historyRecord = [PSCustomObject]@{
                id = $timestamp
                date = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
                zipName = $expectedZip
                backupRel = ".history/$relPath/$backupZipFile"
                backupSize = $backupSize
                newSize = $bytes.Length
                entries = $entryCount
            }
            $currHist = @($meta.taggedFolders.$relPath.history)
            $currHist = @($historyRecord) + $currHist
            $meta.taggedFolders.$relPath.history = $currHist
            Save-NoeraMeta $meta

            Send-Json $ctx 200 @{
                ok = $true
                path = $relPath
                zipName = $expectedZip
                history = $historyRecord
                meta = $meta
            }
            return
        }

        'GET /api/folder/history/download' {
            $relFile = [string]$q['file']
            $relFile = $relFile.Replace('/', '\').Trim('\')
            if (-not $relFile.StartsWith('.history\')) { Fail 403 'Acceso no permitido.' }
            $full = [IO.Path]::GetFullPath((Join-Path $Root $relFile))
            if (-not $full.StartsWith($Root + '\.history\', [StringComparison]::OrdinalIgnoreCase)) { Fail 403 'Ruta fuera de historial.' }
            if (-not (Test-Path -LiteralPath $full -PathType Leaf)) { Fail 404 'Archivo de respaldo no encontrado.' }
            $bytes = [IO.File]::ReadAllBytes($full)
            $name = Split-Path -Leaf $full
            Send-Bytes $ctx 200 'application/zip' $bytes @{ 'Content-Disposition' = "attachment; filename=`"$name`"" }
            return
        }

        default { Fail 404 'Endpoint no encontrado.' }
    }
}

# ---------- arranque ----------
$listener = $null
for ($p = $Port; $p -lt ($Port + 10); $p++) {
    $l = New-Object System.Net.HttpListener
    $l.Prefixes.Add("http://127.0.0.1:$p/")
    try { $l.Start(); $listener = $l; $Port = $p; break } catch { $l.Close() }
}
if (-not $listener) { Write-Host "No se pudo abrir ningún puerto entre $Port y $($Port + 9)." -ForegroundColor Red; exit 1 }

$url = "http://127.0.0.1:$Port/"
Write-Host ""
Write-Host "  NOERA - Central de archivos" -ForegroundColor Yellow
Write-Host "  Carpeta : $Root"
Write-Host "  Panel   : $url"
Write-Host "  Detener : Ctrl+C o cerrar esta ventana"
Write-Host ""
if (-not $NoBrowser) { Start-Process $url }

try {
    while ($listener.IsListening) {
        $task = $listener.GetContextAsync()
        while (-not $task.AsyncWaitHandle.WaitOne(300)) { }
        $ctx = $task.Result
        try { Handle $ctx }
        catch {
            $m = $_.Exception.Message
            $code = 500
            if ($m -like 'API|*') { $parts = $m.Split('|', 3); $code = [int]$parts[1]; $msg = $parts[2] }
            else { $msg = 'Error interno del servidor.'; Write-Host "[error] $m" -ForegroundColor Red }
            try { Send-Json $ctx $code @{ error = $msg } } catch { try { $ctx.Response.Abort() } catch { } }
        }
    }
}
finally { $listener.Stop(); $listener.Close() }
