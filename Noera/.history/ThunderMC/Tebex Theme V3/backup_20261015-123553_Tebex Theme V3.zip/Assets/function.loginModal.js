// Check if steam is enabled, if is not the avatar will change while typing in the input from login modal

{% if config("serverType") == "Minecraft" %}
const mcIgnInputLegacy = document.querySelector("#mc_IGN_INPUT");
if (mcIgnInputLegacy) {
    mcIgnInputLegacy.addEventListener("keyup", function (e) {
        const avatarEl = document.querySelector("#avatar_MC");
        if (this.value.length > 1) {
            let skin = this.value;
            if (skin[0] === '{{ config("bedrockPrefix") }}') {
                skin = skin.slice(1);
            }
            if (avatarEl) avatarEl.src = `https://minotar.net/avatar/${skin}/32`;
            return;
        }
        if (avatarEl) avatarEl.src = `https://minotar.net/avatar/MHF_Question/32`;
    });
}
{% endif %}

const clickableCategories = document.querySelectorAll("[data-login-category]");
let lastClickedCategoryLink;

if (clickableCategories && clickableCategories.length > 0) {
    clickableCategories.forEach(category => {
        category.addEventListener("click", function (e) {
            e.preventDefault();
            lastClickedCategoryLink = e.target.getAttribute("href");
            if (typeof closeModal === 'function') closeModal();
        });
    });
}

const bedrockUser = document.querySelector("#bedrockIGN");
const loginFormLegacy = document.querySelector(".login-panel form");

if (loginFormLegacy) {
    loginFormLegacy.addEventListener("submit", async function (e) {
        e.preventDefault();
        const username = document.querySelector("#mc_IGN_INPUT");
        if (!username) return;

        if (username.value.length < 3) {
            username.classList.add("login-error");
            return;
        }

        if (bedrockUser?.checked && username.value[0] !== `{{ config("bedrockPrefix") }}`) {
            username.value = `{{ config("bedrockPrefix") }}${username.value}`;
        }

        const loginLoader = document.querySelector(".login-loader");
        const successAnimation = document.querySelector("#successAnimation");
        const loadingAnimated = document.querySelector(".loading__animated");

        if (loginLoader) loginLoader.style.display = "flex";
        username.classList.remove("login-error");

        try {
            const response = await fetch("/login", {
                method: "POST",
                body: new FormData(this)
            });

            if (response.status === 200) {
                setTimeout(() => {
                    if (loadingAnimated) loadingAnimated.style.display = "none";
                    if (successAnimation) successAnimation.style.display = "block";

                    if (lastClickedCategoryLink) {
                        window.location = lastClickedCategoryLink;
                        return;
                    }
                    location.reload();
                }, 1000);
            }
        } catch (err) {
            console.error("Login fetch error:", err);
            if (loginLoader) loginLoader.style.display = "none";
        }
    });
}
